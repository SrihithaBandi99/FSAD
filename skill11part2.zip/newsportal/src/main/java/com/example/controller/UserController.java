package com.example.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class UserController {

    @GetMapping("/users")
    public List<Map<String, String>> getUsers() {

        List<Map<String, String>> users = new ArrayList<>();

        Map<String, String> u1 = new HashMap<>();
        u1.put("id", "1");
        u1.put("name", "Amit");
        u1.put("email", "amit@gmail.com");

        users.add(u1);

        return users;
    }
}