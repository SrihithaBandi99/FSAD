INSERT INTO users (username, password, role)
VALUES ('admin','123','ADMIN');